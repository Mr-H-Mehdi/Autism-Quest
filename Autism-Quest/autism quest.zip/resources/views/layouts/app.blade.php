<x-header />

<main>
    <!-- main content goes here -->
    @yield('content')
</main>

<x-footer />