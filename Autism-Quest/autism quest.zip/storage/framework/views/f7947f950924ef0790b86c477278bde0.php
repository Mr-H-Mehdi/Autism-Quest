<?php $__env->startSection('content'); ?>
<style>
    body{
    background-image: linear-gradient(to right, #fafab5 , #c9dcf9);
}
</style>
<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6 shadow-sm justify-content-center bg-white rounded">
            <h2 class="text-center mb-4">Login</h2>
            <form action="/users/login" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>"  required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error text-xs text-danger mt-1"><?php echo e($message); ?></p>  
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" id="password" name="password" value="<?php echo e(old('password')); ?>"  required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error text-xs text-danger mt-1"><?php echo e($message); ?></p>  
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary btn-block mb-4">Login</button>
            </form>

            <p class="text-center">Don't have an account? <a href="/register">Register</a></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\5th semester\WE\Autism-Quest\Autism-Quest\resources\views/users/login.blade.php ENDPATH**/ ?>