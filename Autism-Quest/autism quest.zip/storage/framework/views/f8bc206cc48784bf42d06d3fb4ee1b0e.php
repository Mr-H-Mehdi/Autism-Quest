<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/userStories.css')); ?>">
<style>
    footer{
      position: fixed;
      left: 0;
      bottom: 0;
      width: 100%;
      text-align: center;
    }
    #test:hover {
    background-color: #5bc0de;
    color: white;
}
</style>
    <div class="container">
        <?php if(count($stories) > 0): ?>
            <div class="row">
                <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-4 mt-4">
                        <div class="card h-100">
                            <img src="<?php echo e($story->image ? asset('storage/'.$story->image):asset('/images/userStory.jpg')); ?>" class="card-img-left" alt="<?php echo e($story->title); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($story->title); ?></h5>
                                <p class="card-text"><?php echo e($story->story); ?></p>
                            </div>
                            <div class="card-footer text-center" style="display: flex; justify-content: center;">
                                <a href="<?php echo e(route('edit', ['id' => $story->id])); ?>" class="btn btn-secondary mx-2">Edit <i class="fa-solid fa-pen-to-square"></i></a>
                                <form action="/userStories/<?php echo e($story->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger mx-2">Delete <i class="fa-solid fa-trash"></i></button>
                                </form>
                            </div>                        
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="d-flex justify-content-center">
                <?php echo e($stories->links('pagination::bootstrap-4')); ?>

            </div>
        <?php else: ?>
        <a style="text-decoration:none"href="/userStories/create">
            <div id="test" class="container text-center mt-5 shadow-sm bg-white rounded p-2 text-info border border-info">
                <h2>No stories found. Post one today!</h2>
            </div>
        </a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\5th semester\WE\Autism-Quest\Autism-Quest\resources\views/userStories/show.blade.php ENDPATH**/ ?>