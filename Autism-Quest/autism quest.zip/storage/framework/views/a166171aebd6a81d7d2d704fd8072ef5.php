<?php $__env->startSection('content'); ?>
<style>
    body{
    background-image: linear-gradient(to right, #fafab5 , #c9dcf9);
}
</style>
<div class="container">
    <section class="vh-100">
        <div style="width:100%; height:70px; background-color:#9AD0C2" class="mt-4 rounded text-center text-dark mx-auto border border-dark">
            <h2 class="mt-3">Hospitals</h2>
        </div>    
        <div class="row mb-6">
            <?php $__currentLoopData = $hospitals->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mt-4">
                    <div class="card mb-4  h-100 bg-white">
                        <img src="<?php echo e($hospital->image ? asset('storage/'.$hospital->image):asset('/images/hospital.jpg')); ?>" class="card-img-left" alt="<?php echo e($hospital->title); ?>">   
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($hospital->name); ?></h5>
                            <p class="card-text"><?php echo e($hospital->description); ?></p>
                            <p class="card-text"><strong>Location:</strong> <?php echo e($hospital->location); ?></p>
                        </div>
                    </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($hospitals->links('pagination::bootstrap-4')); ?> <!-- Bootstrap pagination links for educational institutes -->
        </div>
    </section>

    <section class="vh-100">
        <div style="width:100%; height:70px; background-color:#9AD0C2" class="mt-4 rounded text-center text-dark mx-auto border border-dark">
            <h2 class="mt-3">educational Institutes</h2>
        </div>  
        <div class="row">
            <?php $__currentLoopData = $educationalInstitutes->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mt-4">
                    <div class="card mb-4  h-100 bg-white">
                        <img src="<?php echo e($institute->image ? asset('storage/'.$institute->image):asset('/images/school.jpg')); ?>" class="card-img-left" alt="<?php echo e($institute->title); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($institute->name); ?></h5>
                            <p class="card-text"><?php echo e($institute->description); ?></p>
                            <p class="card-text"><strong>Location:</strong> <?php echo e($institute->location); ?></p>
                        </div>
                    </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($educationalInstitutes->links('pagination::bootstrap-4')); ?> <!-- Bootstrap pagination links for educational institutes -->
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\5th semester\WE\Autism-Quest\Autism-Quest\resources\views/resources/index.blade.php ENDPATH**/ ?>